package global;

public class Constants {

	// final�� ���� ��� ǥ��
	// �빮�ڷ� ���� ��κ� ��� (������ ��)
	public static enum EDataFileName {
		serialVersionUID("1"), path("Data/"), root("root"),
		login("login"), personalInfo("student"), refresh("englishYG"),
		basketFileName("basketFile"), resultFileName("resultFile");

		private String value;

		private EDataFileName(String value) {
			// constructor
			this.value = value;
		}

		public int getInt() {
			return Integer.parseInt(this.value);
		}

		public String getString() {
			return this.value;
		}

	}
	public static enum EMainCmd {
		personalInfo("��������"),logout("�α׾ƿ�");

		private String value;

		private EMainCmd(String value) {
			// constructor
			this.value = value;
		}

		public int getInt() {
			return Integer.parseInt(this.value);
		}

		public String getString() {
			return this.value;
		}

	}
	public static enum ETMainFrame { // static = new���� �ʾƵ� �ڵ����� �Ҵ�
		serialVersionUID("1"), title("������û"),
		damgiBtn("damgi"), sincheongBtn("sincheong");
		// ���� �о������ ���� ""�� null�� �س��� ���� �о������ �ϸ� ��.
		private String value;

		private ETMainFrame(String value) {
			// constructor
			this.value = value;
		}

		public int getInt() {
			return Integer.parseInt(this.value);
		}

		public String getString() {
			return this.value;
		}

	}

	public static enum EGMainFrame {
		serialVersionUID("1"), width("1000"), height("700"),
		damgiBtn("images/basketBtn.png"), sincheongBtn("images/sugangBtn.png"),
		damgiBtnPressed("images/basketBtnPress.png"), sincheongBtnPressed("images/sugangBtnPress.png");

		private String value;

		private EGMainFrame(String value) {
			// constructor
			this.value = value;
		}

		public int getInt() {
			return Integer.parseInt(this.value);
		}

		public String getString() {
			return this.value;
		}
	}

	public static enum ETLoginDialog {
		serialVersionUID("1"), lTitle("�α���"), lbInsaPostfix("���̵�"), nameLabel("���̵�    "), passwordLabel(
				"��й�ȣ"), okButton("Login"), cancelButton("Cancel"),
		mainLogo("images/������ �ΰ�.png"), loginBtn("images/loginBtn.png"),
		closeBtn("images/closeBtn.png"), loginBtnPressed("images/loginBtnPress.png"),
		closeBtnPressed("images/closeBtnPress.png"), idsave("���̵� ����");

		private String value;

		private ETLoginDialog(String value) {
			// constructor
			this.value = value;
		}

		public int getInt() {
			return Integer.parseInt(this.value);
		}

		public String getString() {
			return this.value;
		}
	}

	public static enum EGLoginDialog {
		serialVersionUID("1"), width("590"), height("350"), textSize("15");

		private String value;

		private EGLoginDialog(String value) {
			// constructor
			this.value = value;
		}

		public int getInt() {
			return Integer.parseInt(this.value);
		}

		public String getString() {
			return this.value;
		}
	}

	public static enum EPersonalInfo {
		serialVersionUID("1"), lbInsaPostfix("�� ȯ���մϴ�"),
		btnInfo("��������"), btnLogout("�α׾ƿ�"),
		pInfoBtn("images/pInfoBtn.png"),logoutBtn("images/logoutBtn.png"),
		pInfoBtnPressed("images/pInfoBtnPress.png"),
		logoutBtnPressed("images/logoutBtnPress.png"),
		idInfo("�й�: "), nameInfo("�̸�: "), gradeInfo("�г�: "),
		gwaInfo("�а�: ");


		private String value;

		private EPersonalInfo(String value) {
			// constructor
			this.value = value;
		}

		public int getInt() {
			return Integer.parseInt(this.value);
		}

		public String getString() {
			return this.value;
		}
	}
	public static enum EDirectoryPanel {
		serialVersionUID("1"),
		hDaehak("����"),
		hHakgwa("�а�"), 
		hGwamok("����");

		private String value;

		private EDirectoryPanel(String value) {
			// constructor
			this.value = value;
		}

		public int getInt() {
			return Integer.parseInt(this.value);
		}

		public String getString() {
			return this.value;
		}
	}

	public static enum ELecturePanel {
		serialVersionUID("1"),lNumber("���¹�ȣ"), lName("���¸�"), lProfessor("��米��"), lScore("����"), lTime("�ð�");

		private String value;

		private ELecturePanel(String value) {
			// constructor
			this.value = value;
		}

		public int getInt() {
			return Integer.parseInt(this.value);
		}

		public String getString() {
			return this.value;
		}
	}

	public static enum ErrorDialog {
		serialVersionUID("1"), errorM("Ʋ�Ƚ��ϴ�."), errorT("�α��� ����"),
		basketEM("�̹� ��û�� �����Դϴ�."), basketET("��û �ȳ�");

		private String value;

		private ErrorDialog(String value) {
			// constructor
			this.value = value;
		}

		public int getInt() {
			return Integer.parseInt(this.value);
		}

		public String getString() {
			return this.value;
		}

	}

	public static enum EBasketPanel{
		id("�����ȣ"),
		name("�����"),
		professorName("������");
//		credit("����"),
//		time("�ð�");
		
		private String value;
		private EBasketPanel(String value){
			this.value = value;
		}
		public String getString(){
			return  this.value;
		}
		public int getInt() {
			return Integer.parseInt(this.value);
		}
	}
	
	public static enum EMoveMtnImg{
		moveBtn("images/moveBtn.png"), removeBtn("images/removeBtn.png"),
		moveBtnPressed("images/moveBtnPress.png"),removeBtnPressed("images/removeBtnPress.png");
		
		private String value;
		private EMoveMtnImg(String value) {
			this.value = value;
		}
		public String getString(){
			return  this.value;
		}
		public int getInt() {
			return Integer.parseInt(this.value);
		}
	}
	
	public static enum EMoveMtnCmd{
		rightBtn("rightButton"), leftBtn("leftButton");
		
		private String value;
		private EMoveMtnCmd(String value) {
			this.value = value;
		}
		public String getString(){
			return  this.value;
		}
		public int getInt() {
			return Integer.parseInt(this.value);
		}
	}
	

}