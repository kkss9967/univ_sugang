package view;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import control.CLogin;
import global.Constants.EGLoginDialog;
import global.Constants.ETLoginDialog;
import global.Constants.ErrorDialog;

public class LoginDialog extends JDialog {
	private static final long serialVersionUID = 1L;	//�α��� ���̾�α׿��� ���� ������ ���� ������ ������ �� �ȴ�. ���⿡�� �ڱ� �ڽ� �׸��� �͸� �ִ�. 
	private JLabel nameLabel;
	private JTextField nameText;
	private JLabel passwordLabel;
	private JTextField passwordText;
	private JButton okButton;
	private JButton cancelButton;
	private JCheckBox idsave;

	private ImageIcon mainLogo = new ImageIcon(ETLoginDialog.mainLogo.getString());
	
	private ImageIcon loginBtn = new ImageIcon(ETLoginDialog.loginBtn.getString());
	private ImageIcon closeBtn = new ImageIcon(ETLoginDialog.closeBtn.getString());
	private ImageIcon loginBtnPressed = new ImageIcon(ETLoginDialog.loginBtnPressed.getString());
	private ImageIcon closeBtnPressed = new ImageIcon(ETLoginDialog.closeBtnPressed.getString());
	
	private CLogin cLogin;
	
	private String id;

	public String getID() {
		return id;
	}
	public void setID(String id) {
		this.id = id;
	}

	public LoginDialog(ActionListener actionHandler, ActionListener enterKey) {
		// �Ӽ� ���� ���α׷��� specialization
		
		this.setSize(EGLoginDialog.width.getInt(), EGLoginDialog.height.getInt());

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();	
		this.setLocation(dim.width / 2 - this.getSize().width / 2, dim.height / 2 - this.getSize().height / 2);
		//�Ӽ�
		this.setLayout(new GridLayout(1, 4));
		this.setTitle(ETLoginDialog.lTitle.getString());
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

		JPanel bincan;
		// �ڽ�(components(��ǰ))	
		JLabel image = new JLabel(mainLogo);
		this.add(image);
		
		JPanel top = new JPanel();
		top.setLayout(new GridLayout(6,2));
		bincan = new JPanel();
		top.add(bincan);
		
		JPanel panel1 = new JPanel();
		nameLabel = new JLabel(ETLoginDialog.nameLabel.getString());	//�Ϻ� �Ӽ� ����
		panel1.add(nameLabel);				//�ڽ� ���
		nameText = new JTextField(EGLoginDialog.textSize.getInt());
		nameText.addActionListener(enterKey);
		panel1.add(nameText);
		top.add(panel1);
		
		JPanel panel2 = new JPanel();
		passwordLabel = new JLabel(ETLoginDialog.passwordLabel.getString());
		panel2.add(passwordLabel);
		passwordText = new JPasswordField(EGLoginDialog.textSize.getInt());		
		passwordText.addActionListener(enterKey);
		panel2.add(passwordText);
		top.add(panel2);
	
		JPanel idf= new JPanel();
		idsave = new JCheckBox(ETLoginDialog.idsave.getString());
		idf.add(idsave);
		top.add(idf);
		
		JPanel panel3 = new JPanel();
		okButton = new JButton(loginBtn);
		okButton.addActionListener(actionHandler);
		okButton.setActionCommand(ETLoginDialog.okButton.getString());
		panel3.add(okButton);

		cancelButton = new JButton(closeBtn);
		cancelButton.addActionListener(actionHandler);
		cancelButton.setActionCommand(ETLoginDialog.cancelButton.getString());
		panel3.add(cancelButton);
		add(panel3);
		top.add(panel3);
		this.add(top);
		
		okButton.setBorderPainted(false);
		okButton.setContentAreaFilled(false);
		okButton.setFocusable(false);
		okButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				okButton.setIcon(loginBtnPressed);
				okButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				okButton.setIcon(loginBtn);
				okButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		});
		cancelButton.setBorderPainted(false);
		cancelButton.setContentAreaFilled(false);
		cancelButton.setFocusable(false);
		cancelButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				cancelButton.setIcon(closeBtnPressed);
				cancelButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				cancelButton.setIcon(closeBtn);
				cancelButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		});
		
	}
	public void Select() {
		if(idsave.isSelected()) {
			ClearPw();
		}else {
			ClearAll();
		}
	}
	public void ClearPw() {
		passwordText.setText("");
	}
	public void ClearAll() {
		nameText.setText("");
		passwordText.setText("");
	}
	
	public void initialize() {
		
	}	
	public String validateUser() {
		String id = nameText.getText();
		String password = passwordText.getText();
		
		this.cLogin = new CLogin();
		boolean result = cLogin.validateUser(id, password);
		if (result) {
			return id;
		} else {
			JOptionPane.showMessageDialog(this, ErrorDialog.errorM.getString(), ErrorDialog.errorT.getString(), JOptionPane.INFORMATION_MESSAGE);
			return null;
		}		
	}
	
	public void cancel() {
		this.dispose();
	}
	

}