package view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Calendar;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import control.CPersonalInfo;
import global.Constants.EGLoginDialog;
import global.Constants.EPersonalInfo;
import valueObject.VCPersonalInfo;

public class PersonalInfoPanel extends JPanel implements Runnable{
	private static final long serialVersionUID = 1L;
	
	private JLabel lbInsa;
	private JLabel grade, gwa, number, name;
	private JLabel lbInsaPostfix;
	private JButton btnInfo, btnLogout;
	private Thread thread;
	private String now;
	private JLabel label;
	private JLabel nameInfo, gradeInfo, gwaInfo, idInfo;
	
	private ImageIcon pInfoBtn = new ImageIcon(EPersonalInfo.pInfoBtn.getString());
	private ImageIcon logoutBtn = new ImageIcon(EPersonalInfo.logoutBtn.getString());
	private ImageIcon pInfoBtnPressed = new ImageIcon(EPersonalInfo.pInfoBtnPressed.getString());
	private ImageIcon logoutBtnPressed = new ImageIcon(EPersonalInfo.logoutBtnPressed.getString());
	
	public PersonalInfoPanel(ActionListener actionHandler) {
		this.setLayout(new GridLayout(1, 3));
	
		label = new JLabel();
		if (thread == null) {
			thread = new Thread(this);
			thread.start();
		}
		add(label);

		label.setText(now);
		this.add(label);
		JPanel info = new JPanel();
		info.setBackground(Color.CYAN);
		this.lbInsa = new JLabel();
		info.add(this.lbInsa);	
		this.lbInsaPostfix = new JLabel(EPersonalInfo.lbInsaPostfix.getString());
		info.add(lbInsaPostfix);
		this.add(info);
		
		JPanel button = new JPanel();
		button.setBackground(Color.CYAN);
		this.btnInfo = new JButton(pInfoBtn);
		this.btnInfo.addActionListener(actionHandler);
		this.btnInfo.setActionCommand(EPersonalInfo.btnInfo.getString());
		button.add(this.btnInfo);	//��������
		btnInfo.setBorderPainted(false);
		btnInfo.setContentAreaFilled(false);
		btnInfo.setFocusable(false);
		btnInfo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnInfo.setIcon(pInfoBtnPressed);
				btnInfo.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				btnInfo.setIcon(pInfoBtn);
				btnInfo.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		});
		this.btnLogout = new JButton(logoutBtn);
		this.btnLogout.addActionListener(actionHandler);
		this.btnLogout.setActionCommand(EPersonalInfo.btnLogout.getString());
		button.add(this.btnLogout);	//�α׾ƿ�
		btnLogout.setBorderPainted(false);
		btnLogout.setContentAreaFilled(false);
		btnLogout.setFocusable(false);
		btnLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnLogout.setIcon(logoutBtnPressed);
				btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				btnLogout.setIcon(logoutBtn);
				btnLogout.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		});
		this.add(button);
		
		grade = new JLabel();
		gwa = new JLabel();
		number = new JLabel();
		name = new JLabel();
	}

	public void initialize(String id) {
		this.showPersonalInfo(id);
		
	}
	public void run() {
		while (true) {
			Calendar cal = Calendar.getInstance();
			now = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DATE) + " "
					+ cal.get(Calendar.HOUR) + ":" + cal.get(Calendar.MINUTE) + ":" + cal.get(Calendar.SECOND);
			label.setText(now);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	private void showPersonalInfo(String id) {
		CPersonalInfo cPersonalInfo = new CPersonalInfo();
		VCPersonalInfo vPersonalInfo = cPersonalInfo.getPersonalInfo(id);
		this.lbInsa.setText(vPersonalInfo.getName());
		this.name.setText(vPersonalInfo.getName());
		this.number.setText(vPersonalInfo.getId());
		this.grade.setText(vPersonalInfo.getGrade());
		this.gwa.setText(vPersonalInfo.getGwa());
	}

	public void ShowMe() {

		JDialog show = new JDialog();
		show.setSize(EGLoginDialog.width.getInt(), EGLoginDialog.height.getInt());
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		show.setLocation(dim.width / 2 - show.getSize().width / 2, dim.height / 2 - show.getSize().height / 2);

		show.setTitle(EPersonalInfo.btnInfo.getString());
		show.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		show.setLayout(new GridLayout(4, 2));

		JPanel info;

		info = new JPanel();
		info.setBackground(Color.white);
		this.idInfo = new JLabel(EPersonalInfo.idInfo.getString());
		info.add(idInfo);
		info.add(number);
		show.add(info);

		info = new JPanel();
		info.setBackground(Color.white);
		this.nameInfo = new JLabel(EPersonalInfo.nameInfo.getString());
		info.add(nameInfo);
		info.add(name);
		show.add(info);

		info = new JPanel();
		info.setBackground(Color.white);
		this.gradeInfo = new JLabel(EPersonalInfo.gradeInfo.getString());
		info.add(gradeInfo);
		info.add(grade);
		show.add(info);

		info = new JPanel();
		info.setBackground(Color.white);
		this.gwaInfo = new JLabel(EPersonalInfo.gwaInfo.getString());
		info.add(gwaInfo);
		info.add(gwa);
		show.add(info);
		show.setVisible(true);

	}


}
