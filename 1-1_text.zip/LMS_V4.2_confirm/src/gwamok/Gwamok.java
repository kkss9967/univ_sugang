package gwamok;

import java.util.Scanner;

public class Gwamok {
	//���´� ���� �Ѱ�, �л� n�� ����

	private int id;
	private String name;
		
	public int getId() {return id;}
	public String getName() {return name;}

	public void readFromFile(Scanner scan) {

			this.id = scan.nextInt();
			this.name = scan.next();
			
		}
	public void printInfo() {
		System.out.println(this.id +" "+ this.name);
		
	}
	
}