package haksaeng;

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;

import gangjwa.GangjwaList;
import quick.Quick;
import valueObject.Sungjuk;

public class Haksaeng {
	
   private int id;
   private String name;
 
   public int getId() {return id;}
   public String getName() {return name;}
   
   public void readFromFile(Scanner scan) {
      this.id = scan.nextInt();
      this.name = scan.next();      
}
  
   public void printInfo(GangjwaList gangjwaList) throws FileNotFoundException{
	 //���ϴ� ���� ����Ʈ. �л��� ���� ����Ʈ ���ÿ��̼� �س��� ��.
	   System.out.println(id +" "+ name);
	  Vector<Sungjuk> sungjukList = gangjwaList.getSungjuk(id);
	  
	  int[] year = new int[100];
	  int[] semester = new int[100];
	  String[] gwamokName = new String[100];
	  String[] name = new String[100];
	  int[] kimal = new int[100];
	  char[] grade = new char[100];
	  int count = 0;
	  
	  for(Sungjuk sungjuk : sungjukList) {	 
		  if(sungjuk != null) {
			  if(sungjuk.getGwamokName() != null) {
		year[count] = sungjuk.getYear();
		semester[count] = sungjuk.getSemester();
		gwamokName[count] = sungjuk.getGwamokName();
		name[count] = sungjuk.getName();
		kimal[count] = sungjuk.getKimal()[id-1];
		grade[count] = sungjuk.getGrade()[id-1];
			
		count++;
			  } 			  
		  }
	  }
	  int count1 = 0;
	  for(Sungjuk sungjuk : sungjukList) {	 	
		  if(sungjuk != null) {
			  if(sungjuk.getGwamokName() != null) {
				  
				  int left = 0;
				  int right = count-1;
				  
			  Quick quick = new Quick();
			  quick.quickup(left, right, year, semester, gwamokName, name, kimal, grade);
			  quick.Ssem(year, semester, gwamokName, name, kimal, grade);
			System.out.println(year[count1] +"�� "+ semester[count1] + "�б� " + gwamokName[count1] + " " + name[count1] + " " + kimal[count1]+ "�� " + grade[count1]);
	
			count1++;
   }
		  }
	  }
}
}