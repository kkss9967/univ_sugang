package haksaeng;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;

import exception.HaksaengNumberNotExistException;
import gangjwa.GangjwaList;

public class HaksaengList {

	private Vector<Haksaeng> haksaengVector;
	
	GangjwaList gangjwaList;
	
	public void associate(GangjwaList gangjwaList) {
		this.gangjwaList = gangjwaList;			
	}
	 
	public HaksaengList(){ 
		this.haksaengVector = new Vector<Haksaeng>();
	}
			
	public String getHaksaengName(int haksaengID) throws HaksaengNumberNotExistException {
		
		for(Haksaeng haksaeng : this.haksaengVector){
			if (haksaeng.getId() == haksaengID){
				return haksaeng.getName();
			}
		}
		 throw new HaksaengNumberNotExistException(haksaengID);
	}
	
	public void readFromFile() throws FileNotFoundException{
							
			File file = new File("data/haksaeng.txt");
			Scanner scan = new Scanner(file);

			while(scan.hasNext()){	
				Haksaeng haksaeng = new Haksaeng();	
				haksaeng.readFromFile(scan);				
				this.haksaengVector.add(haksaeng);	
			}						
			scan.close();			
		} 

	public void printInfo(GangjwaList gangjwaList){
		for (Haksaeng haksaeng: haksaengVector) {
			   System.out.println('\n' + "========= Haksaeng Info ==========");	

			try {
				haksaeng.printInfo(gangjwaList);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
	}
	}
	}