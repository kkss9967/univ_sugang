package gangjwa;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;

import exception.GwamokNameNotFoundException;
import gwamok.GwamokList;
import haksaeng.HaksaengList;
import valueObject.Sungjuk;

public class GangjwaList {
	
private Vector<Gangjwa> gangjwaVector;//�л�����Ʈ�� �л����ʹ� ���԰����̴�. �ڽİ���(aggregation)
	
GwamokList gwamokList;
HaksaengList haksaengList;

	public GangjwaList(){ 
		this.gangjwaVector = new Vector<Gangjwa>();
	}
	
	public void associate(GwamokList gwamokList, HaksaengList haksaengList) {
		this.gwamokList = gwamokList;
		this.haksaengList = haksaengList;		
	}
	
	public void readFromFile() throws FileNotFoundException {
				
		File file = new File("data/gangjwaList.txt");	
		Scanner scan = new Scanner(file);
		while(scan.hasNext()){	
			String name = scan.next();
			Gangjwa gangjwa = new Gangjwa();
			gangjwa.readFromFile(name);
			this.gangjwaVector.add(gangjwa);
		}					
		scan.close();			
	}

	public Vector<Sungjuk> getSungjuk(int id) throws FileNotFoundException{
		Vector<Sungjuk> sungjukList = new Vector<Sungjuk>();
		for(Gangjwa gangjwa : this.gangjwaVector) {
			Sungjuk sungjuk = gangjwa.getSungjuk(id);
			if(sungjuk != null) {
				sungjukList.add(sungjuk);
			}			
		}
		return sungjukList;
	}
	
	
	public void printInfo(GwamokList gwamokList,HaksaengList haksaengList){
		for (Gangjwa gangjwa: gangjwaVector) {
			System.out.println('\n' + "========= Gangjwa Information =========");		
			//���� �� ������ n�� �ݺ��ض�.
			try {
				gangjwa.printInfo(gwamokList, haksaengList);
			} catch (GwamokNameNotFoundException e) {
				e.printStackTrace();
			}	//���¸���Ʈ�� �л� ����Ʈ�� ���񸮽�Ʈ�� �˰� �־�� ��	-> ���¿��� �˷���� ��
		
		}	
	}
}